const ContactForm = () => {
  return null;
}

export default ContactForm;