const ServicesSection = () => {
  return null;
}

export default ServicesSection;